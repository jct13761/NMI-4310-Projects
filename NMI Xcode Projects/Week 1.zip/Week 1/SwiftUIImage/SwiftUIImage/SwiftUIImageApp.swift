//
//  SwiftUIImageApp.swift
//  SwiftUIImage
//
//  Created by Jorrin Thacker on 1/19/21.
//

import SwiftUI

@main
struct SwiftUIImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
