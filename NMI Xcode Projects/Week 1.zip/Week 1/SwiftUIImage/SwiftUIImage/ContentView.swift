//
//  ContentView.swift
//  SwiftUIImage
//
//  Created by Jorrin Thacker on 1/19/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Image(systemName: "cloud.heavyrain")
            .font(.system(size: 100))
            .foregroundColor(.blue)
            .shadow(color: .gray, radius: 10, x: 0, y: 10)
        Image("kermit")
            .resizable() // resizes to fit to the sides of screen
            //            .edgesIgnoringSafeArea(.all) // stretches to fit all edges
            //            .scaledToFit() // scales with respect to aspect ration
            .aspectRatio(contentMode: .fit) // same thing as scaledToFit(). can use .fill instead
            .frame(width: 300)
            //            .clipped() // clips the image to the box in the viewer. needs to be used with .fill
            .clipShape(Circle())
            //            .opacity(0.5) // set the opacity of hte image
            //This will overlay an image over the image
            .overlay(
                Image(systemName: "heart.fill")
                    .font(.system(size: 50))
                    .foregroundColor(.white)
                    .opacity(0.5)
            )
        
        
//        image with text as overlay
        Image("kermit")
            .resizable()
            .aspectRatio(contentMode: .fit) // same thing as scaledToFit(). can use .fill instead
            .frame(width: 375)
            .overlay(
                Text("If you are lucky enough to have lived in Paris as a young man, then wherever you go for the rest of your life it stays with you, for Paris is a moveable feast.\n\n- Ernest Hemingway")
                    .fontWeight(.heavy)
                    .font(.system(.headline, design: .rounded))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                    .cornerRadius(10)
                    .opacity(0.8)
                    .padding(),
                alignment: .top
                
            )
        
        Image("kermit")
            .resizable()
            .aspectRatio(contentMode: .fit) // same thing as scaledToFit(). can use .fill instead
            .overlay(
                Rectangle()
                    .foregroundColor(.black)
                    .opacity(0.5)
            
//                same effect as above
//                Color.black
//                    .opacity(0.5)
            )
        
        Image("kermit")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 300)
            .overlay(
                Color.black
                    .opacity(0.4)
                    .overlay(
                        Text("Kermit")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .frame(width: 200)
                    )
            )

        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
