//
//  SwitfUITextApp.swift
//  SwitfUIText
//
//  Created by Jorrin Thacker on 1/16/21.
//

import SwiftUI

@main
struct SwitfUITextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
