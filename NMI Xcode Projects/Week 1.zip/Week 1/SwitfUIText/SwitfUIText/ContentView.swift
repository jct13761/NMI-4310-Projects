//
//  ContentView.swift
//  SwitfUIText
//
//  Created by Jorrin Thacker on 1/16/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        Text("Your time is limited, so don’t waste it living someone else’s life. Don’t be trapped by dogma - which is living with the results of other people’s thinking. Don’t let the noise of others’ opinions drown out your own inner voice. And most important, have the courage to follow your heart and intuition.")
//            .fontWeight(.bold)
//            .font(.title)
//            .foregroundColor(.gray)
//            .multilineTextAlignment(.center) // center the text
//            //        .lineLimit(3) // limit the number of lines
//            .truncationMode(.head) // truncate the text to show the first 2 lines and the end of the last line
//            .lineSpacing(10) // set the spacing of the lines
//            .padding()
//            //            .rotationEffect(.degrees(20), anchor: UnitPoint(x: 0, y: 0)) // 2D Rotation
//            .rotation3DEffect(.degrees(60), axis: (x: 1, y: 0, z: 0))
//            .shadow(color: .gray, radius: 2, x: 0, y: 15)
        
        
                Text("Alive. \nAha. \nFuck.").fontWeight(.bold)
                   .font(.system(.title, design: .rounded)) // this font size will scale
                    .font(.system(size: 20)) // This size is static
                    .font(.custom("Courier", size: 25)) // set a custom font
                    .foregroundColor(.green)
                    .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
