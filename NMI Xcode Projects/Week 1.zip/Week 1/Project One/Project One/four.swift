//
//  four.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

struct four: View {
    var body: some View {
        ZStack{
            Color.yellow
            Text("Yellow")
        }
        
    }
}

struct four_Previews: PreviewProvider {
    static var previews: some View {
        four()
    }
}
