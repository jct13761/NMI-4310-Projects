//
//  Project_OneApp.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

@main
struct Project_OneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
