//
//  one.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

struct one: View {
    var body: some View {
        ZStack{
            Color.purple
            Text("Purple")
        }
    }
}

struct one_Previews: PreviewProvider {
    static var previews: some View {
        one()
    }
}
