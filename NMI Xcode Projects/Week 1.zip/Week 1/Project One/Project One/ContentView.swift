//
//  ContentView.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack(alignment: .leading) {
                NavigationLink(destination: one()){
                    Text("Purple")
                        .font(.largeTitle)
                        .foregroundColor(Color.purple)
                }
                NavigationLink(destination: two()){
                    Text("Red")
                        .font(.largeTitle)
                        .foregroundColor(Color.red)
                }
                NavigationLink(destination: three()){
                    Text("Green")
                        .font(.largeTitle)
                        .foregroundColor(Color.green)
                }
                NavigationLink(destination: four()){
                    Text("Yellow")
                        .font(.largeTitle)
                        .foregroundColor(Color.yellow)
                }
            }
        }
    }

}





struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
