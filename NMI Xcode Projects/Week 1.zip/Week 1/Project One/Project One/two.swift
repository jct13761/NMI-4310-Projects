//
//  two.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

struct two: View {
    var body: some View {
        ZStack{
            Color.red
            Text("Red")
        }
}
}

struct two_Previews: PreviewProvider {
    static var previews: some View {
        two()
    }
}
