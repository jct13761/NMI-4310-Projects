//
//  three.swift
//  Project One
//
//  Created by Jorrin Thacker on 1/15/21.
//

import SwiftUI

struct three: View {
    var body: some View {
        ZStack{
            Color.green
            Text("Green")
        }
        
    }
}

struct three_Previews: PreviewProvider {
    static var previews: some View {
        three()
    }
}
