//
//  JukeStarterApp.swift
//  JukeStarter
//
//  Created by Emuel Aldridge on 10/28/20.
//

import SwiftUI

@main
struct JukeStarterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
