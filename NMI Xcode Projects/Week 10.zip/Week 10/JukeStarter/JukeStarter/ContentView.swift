//
//  ContentView.swift
//  JukeStarter
//
//  Created by Emuel Aldridge on 10/28/20.
//

import SwiftUI
import AVFoundation

var twist: AVAudioPlayer?

struct ContentView: View {
    
    // TO DO:
    //// Add currently playing song
    //// Make button reset when click on song
    
    var songs = [
        SongSetup(artist: "ABBA", songTitle: "Dancing Queen", artistImage: "DancingQueen", soundFile: "dancingqueen.mp3"),
        SongSetup(artist: "Rolling Stones", songTitle: "Paint it Black", artistImage: "stones", soundFile: "stones.m4a"),
        SongSetup(artist: "Chubby Checker", songTitle: "Twist and Shout", artistImage: "chubby", soundFile: "twist.mp3"),
        SongSetup(artist: "Dolly Parton", songTitle: "9 to 5", artistImage: "9to5", soundFile: "9to5.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Chiquitta", artistImage: "Chiquitita", soundFile: "Chiquitita.m4a"),
        SongSetup(artist: "Dexys Midnight Runners", songTitle: "Come On Eileen", artistImage: "ComeOnEileen", soundFile: "ComeOnEileen.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Dancing Queen", artistImage: "DancingQueen", soundFile: "DancingQueen.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Does Your Mother Know", artistImage: "DoesYourMotherKnow", soundFile: "DoesYourMotherKnow.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Gimme! Gimme! Gimme!", artistImage: "GimmeGimmeGimme", soundFile: "GimmeGimmeGimme.m4a"),
        SongSetup(artist: "Fleetwood Mack", songTitle: "Landslide", artistImage: "landslide", soundFile: "landslide.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Mama Mia", artistImage: "MamaMia", soundFile: "MamaMia.m4a"),
        SongSetup(artist: "ABBA", songTitle: "One of Us", artistImage: "OneOfUs", soundFile: "OneOfUs.m4a"),
        SongSetup(artist: "Earth, Wind, & Fire", songTitle: "September", artistImage: "september", soundFile: "september.m4a"),
        SongSetup(artist: "ABBA", songTitle: "Take a Chance on Me", artistImage: "TakeAChanceOnMe", soundFile: "TakeAChanceOnMe.m4a"),
        SongSetup(artist: "A-ha", songTitle: "Take On Me", artistImage: "TakeOnMe", soundFile: "TakeOnMe.mp3"),
        SongSetup(artist: "ABBA", songTitle: "Waterloo", artistImage: "Waterloo", soundFile: "Waterloo.m4a"),
        SongSetup(artist: "ABBA", songTitle: "The Winner Takes It All", artistImage: "WinnerTakesItAll", soundFile: "WinnerTakesItAll.m4a"),
        SongSetup(artist: "The Beatles", songTitle: "Twist and Shout", artistImage: "beatles", soundFile: "twistshout.mp3"),
        SongSetup(artist: "AeroSmith", songTitle: "Walk This Way", artistImage: "aerosmith640", soundFile: "walkthisway.mp3")
    ]
    
    var body: some View {
        
        VStack(alignment: .center) {
            
            ZStack {
                Color.pink
                    .edgesIgnoringSafeArea(.top)
                    .opacity(0.5)
                HStack {
                    Image("jukebox")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                        .padding(.trailing, 40)
                    playPause()
                }
            }
            .frame(height: 200)
            
            Spacer()
            
            List(songs.indices) { index in
                Spacer()
                self.songs[index]
                Spacer()
            }
        }
        Spacer()
    }
}




struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Song: Identifiable {
    var id = UUID()
    var artist: String
    var title: String
    var image: String
    var file: String
}
