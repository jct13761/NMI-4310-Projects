//
//  storage.swift
//  JukeStarter
//
//  Created by Emuel Aldridge on 10/28/20.
//

import SwiftUI
import AVFoundation


struct SongSetup: View {
    
    var artist = "ABBA"
    var songTitle = "The Winner Takes It All"
    var artistImage = "WinnerTakesItAll"
    var soundFile = "WinnerTakesItAll.m4a"
//    @State var NAME : String = ""
//    @State var DURATION : Double = 0.0
//    @State var curTime : Double = 0
    

    
    
    var body: some View {
        VStack() {
            Button(action: {
                playsound(thesong: soundFile)
                playPause().reset()
//                NAME = songTitle
//                DURATION = getSongDuration(file: soundFile)
            }) {
                
                VStack {
                    Text(artist)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                    Text(songTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                    
                    let len = getSongDuration(file: soundFile)
                    
                    Text("Duration in Seconds: \(len, specifier: "%.0f")")
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)

                    ZStack {
                        Image("record")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 150)
                        Rectangle()
                            .frame(width: 75, height: 75)
                            .foregroundColor(.white)
                        Image(artistImage)
                            .resizable()
                            .frame(width: 70, height: 70)
                    }
                    
//                    let len = getSongDuration(file: soundFile)
//                    curTime = getCurrentTime(file: soundFile)
//
//                    ProgressBar(duration: len, currentTime: self.$curTime, progressValue: 4.1)
                    //
                    //                    VStack {
                    //                        Text("\(len)")
                    //                        Text("\(len, specifier: "%.2f")")
                    //                        Text("\(lenInt)")
                    //                    }
                    //                    .foregroundColor(Color.black)
                    //                    .lineLimit(2)
                }
            }
        }
    }
}

struct SongSetup_Previews: PreviewProvider {
    static var previews: some View {
        SongSetup()
    }
}


func playsound (thesong: String) {
    
    let thepath = Bundle.main.path(forAuxiliaryExecutable: thesong)!
    let url = URL(fileURLWithPath: thepath)
    
    do {
        twist = try AVAudioPlayer(contentsOf: url)
        twist?.play()
    } catch {
        // couldn't load file :(
    }
}

func getSongDuration(file: String) -> Double {
    let thepath = Bundle.main.path(forAuxiliaryExecutable: file)!
    let asset = AVURLAsset(url: URL(fileURLWithPath: thepath), options: nil)
    let audioDuration = asset.duration
    let audioDurationSeconds = CMTimeGetSeconds(audioDuration)
    return audioDurationSeconds
}

func getCurrentTime(file: String) -> Double {
    return (twist?.currentTime)!
}

func paws(){
    twist?.pause()
}

func player(){
    twist?.play()
}
