//
//  rectToCir.swift
//  SwiftUIAnimation
//
//  Created by Jorrin Thacker on 3/14/21.
//

import SwiftUI

struct playPause: View {
    
    @State private var isPlay = true
    
    var body: some View {
        VStack {
            ZStack {
                RoundedRectangle(cornerRadius: isPlay ? 40 : 15)
                    .frame(width: 80, height: 80)
                    .foregroundColor(isPlay ? .pink : Color(UIColor.cyan))
                    .overlay(
                        Image(systemName: isPlay ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(.largeTitle))
                            .foregroundColor(.white)
                    )
                RoundedRectangle(cornerRadius: isPlay ? 45 : 20)
                    .stroke(lineWidth: 5)
                    .frame(width: 90, height: 90)
                    .foregroundColor(isPlay ? .pink : Color(UIColor.cyan))
            }
            .onTapGesture {
                withAnimation(Animation.spring()) {
                    self.isPlay.toggle()
                    if isPlay {
                        player()
                    } else {
                        paws()
                    }
                }
            }
        }
    }
    
    func isPlaying() -> Bool {
        return isPlay
    }
    
    
    func reset() {
        isPlay.toggle()
    }
}

struct playPause_Previews: PreviewProvider {
    static var previews: some View {
        playPause()
    }
}
