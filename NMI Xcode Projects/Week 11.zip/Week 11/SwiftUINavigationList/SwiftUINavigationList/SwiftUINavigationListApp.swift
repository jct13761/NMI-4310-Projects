//
//  SwiftUINavigationListApp.swift
//  SwiftUINavigationList
//
//  Created by Simon Ng on 18/8/2020.
//

import SwiftUI

@main
struct SwiftUINavigationListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
