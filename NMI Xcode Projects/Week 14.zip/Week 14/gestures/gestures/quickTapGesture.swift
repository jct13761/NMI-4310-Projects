//
//  quickTapGesture.swift
//  gestures
//
//  Created by Jorrin Thacker on 4/21/21.
//

import SwiftUI

struct quickTapGesture: View {
    @State private var isPressed = false
    var body: some View {
        Image(systemName: "star.circle.fill")
            .font(.system(size: 200))
            .scaleEffect(isPressed ? 0.5 : 1.0)
            .animation(.easeInOut)
            .foregroundColor(.green)
            .gesture(
                TapGesture()
                    .onEnded({
                        self.isPressed.toggle()
                    })
            )
    }
}

struct quickTapGesture_Previews: PreviewProvider {
    static var previews: some View {
        quickTapGesture()
    }
}
