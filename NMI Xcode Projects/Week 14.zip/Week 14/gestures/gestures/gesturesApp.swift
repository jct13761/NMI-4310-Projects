//
//  gesturesApp.swift
//  gestures
//
//  Created by Jorrin Thacker on 4/21/21.
//

import SwiftUI

@main
struct gesturesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
