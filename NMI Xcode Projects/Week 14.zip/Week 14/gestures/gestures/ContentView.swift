//
//  ContentView.swift
//  gestures
//
//  Created by Jorrin Thacker on 4/21/21.
//

import SwiftUI

struct ContentView: View {
    
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: quickTapGesture()){
                    Text("Quick Tap Gesture")
                }
                NavigationLink(destination: longPressGesture()){
                    Text("Long Press Gesture")
                }
                NavigationLink(destination: drag()){
                    Text("Drag Gesture")
                }
                NavigationLink(destination: multipleGeastures()){
                    Text("Multiple Gesture")
                }
                NavigationLink(destination: combinedWithEnum()){
                    Text("Multiple with Enum")
                }
                NavigationLink(destination: DraggableView() {
                    Text("👾")
                        .font(.system(size: 150, weight: .bold, design: .rounded))
                        .bold()
                        .foregroundColor(.red)
                }){
                    Text("Draggable View Gesture")
                }
                NavigationLink(destination: ScalableView() {
                    Image(systemName: "headphones")
                        .font(.system(size: 100))
                        .foregroundColor(.purple)
                }){
                    Text("Scalable View Gesture")
                }
            }
            .font(.largeTitle)
            .foregroundColor(.red)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
