//
//  HW4App.swift
//  HW4
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

@main
struct HW4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
