//
//  SwiftUIButtonApp.swift
//  SwiftUIButton
//
//  Created by Jorrin Thacker on 2/5/21.
//

import SwiftUI

@main
struct SwiftUIButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
