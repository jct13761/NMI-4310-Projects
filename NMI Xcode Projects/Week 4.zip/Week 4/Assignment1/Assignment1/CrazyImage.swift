//
//  CrazyImage.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

struct CrazyImage: View {
    var body: some View {
        ZStack {
            Color.gray
                .opacity(0.7)
                .edgesIgnoringSafeArea(.all)
            Ellipse() // shadow
                .frame(width: 250, height: 50)
                .offset(x: -30, y: 250)
                .foregroundColor(.gray)
            Group { // legs and arms
                // legs
                Ellipse()
                    .frame(width: 20, height: 120)
                    .offset(x: 0, y: 190)
                Ellipse()
                    .frame(width: 20, height: 120)
                    .offset(x: -40, y: 190)
                // right arm
                Ellipse()
                    .frame(width: 120, height: 20)
                    .offset(x: 50, y: 90)
                    .rotationEffect(.init(degrees: -35))
            }
            Circle() // body
                .frame(width: 250, height: 250)
                .offset(x: -30, y: 70)
                .foregroundColor(Color("Pink"))
            Group { // top layer
                Ellipse() // left arm
                    .frame(width: 120, height: 20)
                    .offset(x: 70, y: 160)
                    .rotationEffect(.init(degrees: 65))
                Group { // RIGHT EYE
                    Circle() // right Eye
                        .frame(width: 50, height: 50)
                        .offset(x: 20, y: 20)
                        .foregroundColor(.white)
                    Circle() // right iris
                        .frame(width: 25, height: 25)
                        .offset(x: 30, y: 15)
                        .foregroundColor(.blue)
                    Circle() // right pupil
                        .frame(width: 13)
                        .offset(x: 30, y: 15)
                        .foregroundColor(.black)
                }
                Group { //LEFT EYE
                    Circle() // left Eye
                        .frame(width: 50, height: 50)
                        .offset(x: -40, y: 20)
                        .foregroundColor(.white)
                    Circle() // right iris
                        .frame(width: 25, height: 25)
                        .offset(x: -30, y: 15)
                        .foregroundColor(.blue)
                    Circle() // right pupil
                        .frame(width: 13)
                        .offset(x: -30, y: 15)
                        .foregroundColor(.black)
                }
                Ellipse() // Nose
                    .frame(width: 20, height: 30)
                    .offset(x: -8, y: 70)
                    .foregroundColor(.orange)
                Ellipse() // Mouth
                    .frame(width: 50, height: 30)
                    .offset(x: 0, y: 120)
                Group { // PLANE
                    Ellipse() // plane  body
                        .frame(width: 270, height: 50)
                        .offset(x: 30, y: -200)
                        .foregroundColor(.blue)
                    Ellipse() // big wing
                        .frame(width: 220, height: 40)
                        .offset(x: -180, y: -90)
                        .foregroundColor(.blue)
                        .rotationEffect(.init(degrees: 65))
                    Ellipse() // little wing
                        .frame(width: 80, height: 20)
                        .offset(x: -130, y: -200)
                        .foregroundColor(.blue)
                        .rotationEffect(.init(degrees: 65))
                    Circle() // plane window
                        .frame(width: 13)
                        .offset(x: -80, y: -205)
                        .foregroundColor(.white)
                        .opacity(0.7)
                }
            }
        }
    }
}

struct CrazyImage_Previews: PreviewProvider {
    static var previews: some View {
        CrazyImage()
    }
}
