//
//  SFSymbol.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

struct SFSymbol: View {
    var body: some View {
        
        ZStack {
            Color.black
                .opacity(0.7)
                .edgesIgnoringSafeArea(.all)
            Image(systemName: "ladybug.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .font(.system(size: 100))
                .foregroundColor(.red)
        }
    }
}

struct SFSymbol_Previews: PreviewProvider {
    static var previews: some View {
        SFSymbol()
    }
}
