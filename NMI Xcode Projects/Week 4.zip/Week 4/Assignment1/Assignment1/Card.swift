//
//  Card.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

struct Card: View {
    var image = "me"
    var heading = "About Me!"
    var bodyText = "This is me! I am a senior at UGA with a major in Computer Science!"
    
    var body: some View {
        ZStack {
            VStack {
                Text(heading)
                    .font(.title)
                    .fontWeight(.black)
                    .foregroundColor(Color.white)
                Image(image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding()
                Text(bodyText)
                    .font(.title3)
                    .foregroundColor(Color.white)
                    .padding()
            }
            .padding()
            .background(Rectangle()
                            .cornerRadius(15)
            )
            .frame(height: 600, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            
        }
        
    }
}

struct Card_Previews: PreviewProvider {
    static var previews: some View {
        Card()
    }
}
