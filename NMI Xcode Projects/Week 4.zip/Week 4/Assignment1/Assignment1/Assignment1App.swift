//
//  Assignment1App.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

@main
struct Assignment1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
