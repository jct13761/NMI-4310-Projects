//
//  AboutMe.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/7/21.
//

import SwiftUI

struct AboutMe: View {
    var body: some View {
        
        ZStack {
            Color.black
                .opacity(0.7)
                .edgesIgnoringSafeArea(.all)
            ScrollView(.horizontal, showsIndicators: false) {
                VStack {
                    HStack {
                        Group {
                            Card(image: "me", heading: "This is me!", bodyText: "This is me! I am a senior at UGA with a major in Computer Science!")
                            Card(image: "family", heading: "This is my family", bodyText: "I have 3 siblings: Terik (top-left), Haaken (bottom-left), and Alora (bottom-right)")
                            Card(image: "dog", heading: "This is our puppy", bodyText: "This is Luna, our newest addition to the family! She is 4 months old and is a beagle/lab mix.")
                            Card(image: "game", heading: "Hobbies", bodyText: "My favorite hobbies include video games and watching movies. My favorite show right now is Game of Thrones.")
                        }
                        .frame(width: 350)
                    }
                }
            }
        }    }
}

struct AboutMe_Previews: PreviewProvider {
    static var previews: some View {
        AboutMe()
    }
}
