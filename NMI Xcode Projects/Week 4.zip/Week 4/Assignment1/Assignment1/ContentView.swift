//
//  ContentView.swift
//  Assignment1
//
//  Created by Jorrin Thacker on 2/6/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack{
                Color.black
                    .opacity(0.7)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    NavigationLink(destination: SFSymbol()){
                        HStack {
                            Image(systemName: "ladybug.fill")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                            Text("SF Symbol")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                        }
                    }
                    .buttonStyle(DawgStyle())
                    NavigationLink(destination: AboutMe()){
                        HStack {
                            Image(systemName: "figure.wave")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                            Text("About Me!")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                        }
                    }
                    .buttonStyle(DawgStyle())
                    NavigationLink(destination: CrazyImage()){
                        HStack {
                            Image(systemName: "paintbrush.pointed.fill")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                            Text("Crazy Image")
                                .font(.largeTitle)
                                .foregroundColor(Color.black)
                        }
                    }
                    .buttonStyle(DawgStyle())
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct DawgStyle: ButtonStyle {
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 250)
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [Color("Yellow"), Color("Pink")]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
        
    }
}
