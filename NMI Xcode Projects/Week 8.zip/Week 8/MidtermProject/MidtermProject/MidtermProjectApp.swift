//
//  MidtermProjectApp.swift
//  MidtermProject
//
//  Created by Jorrin Thacker on 3/8/21.
//

import SwiftUI

@main
struct MidtermProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
