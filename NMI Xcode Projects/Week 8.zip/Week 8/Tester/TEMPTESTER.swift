//
//  TEMPTESTER.swift
//  Tester
//
//  Created by Jorrin Thacker on 3/10/21.
//

import SwiftUI

struct TEMPTESTER: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TEMPTESTER_Previews: PreviewProvider {
    static var previews: some View {
        TEMPTESTER()
    }
}
