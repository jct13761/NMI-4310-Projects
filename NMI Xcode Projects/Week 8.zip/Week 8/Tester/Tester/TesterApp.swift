//
//  TesterApp.swift
//  Tester
//
//  Created by Jorrin Thacker on 3/10/21.
//

import SwiftUI

@main
struct TesterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
