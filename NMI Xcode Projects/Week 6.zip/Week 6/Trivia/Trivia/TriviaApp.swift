//
//  TriviaApp.swift
//  Trivia
//
//  Created by Jorrin Thacker on 2/22/21.
//

import SwiftUI

@main
struct TriviaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
