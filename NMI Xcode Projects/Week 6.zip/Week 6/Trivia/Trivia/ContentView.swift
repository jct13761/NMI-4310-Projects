//
//  ContentView.swift
//  Trivia
//
//  Created by Jorrin Thacker on 2/22/21.
//

import SwiftUI
import Foundation
import Combine

struct ContentView: View {
    @ObservedObject var triviaInfo = GetData()
    
    var body: some View {
        NavigationView  {
            List(triviaInfo.questions) { trivia in
                NavigationLink (
                    destination:
                        Text(trivia.answer)
                        .font(.largeTitle)
                        .padding()
                        .foregroundColor(.red)
                ) {
                    VStack(alignment: .leading) {
                        Text(trivia.question)
                            .font(.title2)
                        Text("Click to see the answer!")
                            .foregroundColor(.blue)
                    } //Vstack
                    .padding(.vertical)
                } // NavigationLink
            } // List
            .navigationBarTitle("Trivia Questions!")
            .font(.body)
        } // NavigationView
    } // body
} // ContentView

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

public class GetData: ObservableObject {
    @Published var questions = [DataLayout]()
    @Published var answers = [DataLayout]()
    
    init() {
        load()
    }
    
    func load() {
        let dataUrl = URL(string: "https://jservice.io/api/random?count=10")!
        let decoder = JSONDecoder()
        URLSession.shared.dataTask(with: dataUrl) { (data, response, error) in
            do {
                if let d = data {
                    let decodedLists = try decoder.decode([DataLayout].self, from: d)
                    DispatchQueue.main.async {
                        self.questions = decodedLists
                        self.answers = decodedLists
                    }
                } else {
                    print("No Data")
                } // if-else
            } catch {
                print("Error")
            } // do-catch
        }.resume()
    } // func()
} // GetData()

struct DataLayout: Codable, Identifiable {
    public var id: Int
    public var answer: String
    public var question: String
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case answer = "answer"
        case question = "question"
    } // enum
} // struct
