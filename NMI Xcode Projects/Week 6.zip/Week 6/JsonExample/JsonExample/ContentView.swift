//
//  ContentView.swift
//  JsonExample
//
//  Created by Jorrin Thacker on 2/22/21.
//

import SwiftUI
import Foundation
import Combine

struct ContentView: View {
    @ObservedObject var studentInfo = GetData()
    
    
    var body: some View {
        List(studentInfo.students) {
            student in
            VStack(alignment: .leading) {
                Text(student.name + " " + student.lastName)
                    .font(.largeTitle)
                Text(student.fact)
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

public class GetData: ObservableObject {
    @Published var students = [DataLayout]()
    @Published var lastNames = [DataLayout]()
    @Published var facts = [DataLayout]()

    
    init() {
        load()
    }
    
    
    func load() {
        let dataUrl = URL(string: "https://4310.mynmi.net/tracker/json.php")!
        let decoder = JSONDecoder()
        URLSession.shared.dataTask(with: dataUrl) { (data, response, error) in
            do {
                if let d = data {
                    let decodedLists = try decoder.decode([DataLayout].self, from: d)
                    DispatchQueue.main.async {
                        self.students = decodedLists
                        self.lastNames = decodedLists
                        self.facts = decodedLists
                    }
                } else {
                    print("No Data")
                } // if-else
            } catch {
                print("Error")
            } // do-catch
        }.resume()
    }
}

struct DataLayout: Codable, Identifiable {
    public var id: String
    public var name: String
    public var lastName: String
    public var fact: String
    
    enum CodingKeys: String, CodingKey {
        case id = "counter"
        case name = "stu_name"
        case lastName = "last_name"
        case fact = "fact"
    }
}
