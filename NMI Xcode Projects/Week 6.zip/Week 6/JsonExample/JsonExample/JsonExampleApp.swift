//
//  JsonExampleApp.swift
//  JsonExample
//
//  Created by Jorrin Thacker on 2/22/21.
//

import SwiftUI

@main
struct JsonExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
