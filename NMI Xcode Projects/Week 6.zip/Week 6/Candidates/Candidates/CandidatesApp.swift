//
//  CandidatesApp.swift
//  Candidates
//
//  Created by Jorrin Thacker on 2/21/21.
//

import SwiftUI

@main
struct CandidatesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
