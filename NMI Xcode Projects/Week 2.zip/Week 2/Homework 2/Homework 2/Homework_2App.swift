//
//  Homework_2App.swift
//  Homework 2
//
//  Created by Jorrin Thacker on 1/25/21.
//

import SwiftUI

@main
struct Homework_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
