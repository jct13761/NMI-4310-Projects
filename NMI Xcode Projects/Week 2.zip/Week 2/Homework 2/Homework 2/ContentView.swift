//
//  ContentView.swift
//  Homework 2
//
//  Created by Jorrin Thacker on 1/25/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Candidate(name: "John Ossof", birthplace: "Atlanta Georgia", job: "Investigative Reporter", party: "Democratic", spouse: "Alisha Kramer", theimage: "ossof")
            Candidate(name: "David Perdue", birthplace: "Macon Georgia", job: "United States Senator", party: "Republican", spouse: "Bonnie Perdue", theimage: "perdue")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Candidate: View {
    var name: String
    var birthplace: String
    var job: String
    var party: String
    var spouse: String
    var theimage: String
    var body: some View {
        VStack {
            Text(name)
                .font(.system(size: 35, weight: .heavy, design: .rounded))
                .padding(10)
            VStack(alignment: .leading) {
                TextView(str: birthplace, str2: job)
                HStack{
                    TextView(str: "Party: " + party, str2: "Spouse: " + spouse)
                }
            }
            Image(theimage)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .clipShape(Ellipse())
        }
    }
}

struct TextView: View {
    var str: String
    var str2: String
    var body: some View {
        HStack {
            Text(str)
                .font(.body)
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
            Text(str2)
                .font(.body)
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
        }
    }
}


//struct Candidate: View {
//
//    var name: String
//    var birthplace: String
//    var job: String
//    var party: String
//    var spouse: String
//    var theimage: String
//
//    var body: some View {
//        VStack {
//            Text(name)
//                .font(.system(size: 40, weight: .heavy, design: .rounded))
//                .padding(.bottom, 10)
//            TextView(str: birthplace + "  " + job)
//            TextView(str: "Party: " + party + " Spouse: " + spouse)
//            Image(theimage)
//                .resizable()
//                .aspectRatio(contentMode: .fit)
//                .clipShape(Ellipse())
//        }
//    }
//}
