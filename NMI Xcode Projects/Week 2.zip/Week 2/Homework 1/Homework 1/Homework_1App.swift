//
//  Homework_1App.swift
//  Homework 1
//
//  Created by Jorrin Thacker on 1/21/21.
//

import SwiftUI

@main
struct Homework_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
