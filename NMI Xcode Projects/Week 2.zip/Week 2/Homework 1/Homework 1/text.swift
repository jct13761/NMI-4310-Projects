//
//  text.swift
//  Homework 1
//
//  Created by Jorrin Thacker on 1/21/21.
//

import SwiftUI

struct text: View {
    var body: some View {
        
        Text("A famous Song:")
            .font(.custom("Courier", size: 45))
            .foregroundColor(.red)
        
        
        Text("We're no strangers to love. You know the rules and so do I. A full commitment's what I'm thinking of. You wouldn't get this from any other guy. I just wanna tell you how I'm feeling. Gotta make you understand. Never gonna give you up, Never gonna let you down, Never gonna run around and desert you. Never gonna make you cry, Never gonna say goodbye, Never gonna tell a lie and hurt you - Rick Astley, 1987")
            .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
            .padding(.all)
            .truncationMode(.head)
            .font(.system(size: 18))
        
        
        Text("These word have inspired many")
            .background(Color.blue)
            .foregroundColor(.white)
            .font(.system(size: 28))

    }
}

struct text_Previews: PreviewProvider {
    static var previews: some View {
        text()
    }
}
