//
//  img.swift
//  Homework 1
//
//  Created by Jorrin Thacker on 1/21/21.
//

import SwiftUI

struct img: View {
    var body: some View {
//        Text("Image View")
        
        Image("GrandCanyon")
            .resizable()
            .scaledToFit()
            .overlay(
                Color.black
                    .opacity(0.6)
                    .overlay(
                        Text("Grand Canyon")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .foregroundColor(.white)
                            .frame(width: 200)
                    )
            )

    }
}

struct img_Previews: PreviewProvider {
    static var previews: some View {
        img()
    }
}
