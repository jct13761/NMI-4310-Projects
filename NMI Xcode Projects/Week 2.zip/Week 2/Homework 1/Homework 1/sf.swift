//
//  sf.swift
//  Homework 1
//
//  Created by Jorrin Thacker on 1/21/21.
//

import SwiftUI

struct sf: View {
    var body: some View {
//        Text("SF View")
        
        Image(systemName: "airplane")
            .font(.system(size: 300))
            .rotationEffect(.degrees(-90))
        
    }
}

struct sf_Previews: PreviewProvider {
    static var previews: some View {
        sf()
    }
}
