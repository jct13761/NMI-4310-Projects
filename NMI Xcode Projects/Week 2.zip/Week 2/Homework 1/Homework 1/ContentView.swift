//
//  ContentView.swift
//  Homework 1
//
//  Created by Jorrin Thacker on 1/21/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack(alignment: .leading) {
                NavigationLink(destination: text()){
                    Text("Text View")
                        .font(.largeTitle)
                        .foregroundColor(Color.purple)
                }
                NavigationLink(destination: sf()){
                    Text("SF View")
                        .font(.largeTitle)
                        .foregroundColor(Color.green)
                }
                NavigationLink(destination: img()){
                    Text("Image View")
                        .font(.largeTitle)
                        .foregroundColor(Color.orange)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
