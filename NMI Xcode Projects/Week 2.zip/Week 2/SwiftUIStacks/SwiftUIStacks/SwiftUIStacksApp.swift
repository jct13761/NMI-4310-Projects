//
//  SwiftUIStacksApp.swift
//  SwiftUIStacks
//
//  Created by Jorrin Thacker on 1/25/21.
//

import SwiftUI

@main
struct SwiftUIStacksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
