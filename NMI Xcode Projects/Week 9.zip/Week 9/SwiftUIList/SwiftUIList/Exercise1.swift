//
//  Exercise1.swift
//  SwiftUIList
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

struct Exercise1: View {
    
    var articles = [ article(title: "The Comprehensive Guide to the State Management in iOS", author: "Alexey Naumov", rating: 4, text: "There are many challenges in the software development, but there is one beast that tends to screw things up much more often than the others: the problem of app’s state management and data propagation.", image: "state-management"),
                     article(title: "Using Swift Protocols to Manage App Configuration", author: "Gabriel Theodoropoulos", rating: 4, text: "Hello and welcome to a new tutorial! One of the most common concepts met and used in Swift by all developers is protocols, and I don’t think there’s even one developer who doesn’t know about them.", image: "protocols"),
                     article(title: "Drawing a Border with Rounded Corners", author: "Simon Ng", rating: 4, text: "With SwiftUI, you can easily draw a border around a button or text (and it actually works for all views) using the border modifier.", image: "swiftui-button"),
                     article(title: "Building a Simple Text Editing App", author: "Gabriel Theodoropoulos", rating: 5, text: "Today we are going to focus on a commonly used family of controls which are vital to every application. Their primary purpose is to gather user input as well as to display certain message types to users. We are going to talk about text controls.", image: "macos-programming"),
                     article(title: "Building a Flutter App with Complex UI", author: "Lawrence Tan", rating: 4, text: "Hello there! Welcome to the second tutorial of our Flutter series. In the last tutorial, you learned the basics of building a Flutter app. So if you have not gone through it, please take a pit stop here, visit it first before proceeding with this tutorial.", image: "flutter-app")
    ]
    
    
    var body: some View {
        List(articles) { article in
            articleBox(article: article)
        }
    }
}

struct Exercise1_Previews: PreviewProvider {
    static var previews: some View {
        Exercise1()
    }
}


struct article: Identifiable {
    var id = UUID()
    var title: String
    var author: String
    var rating: Int
    var text: String
    var image: String
}

struct articleBox: View {
    
    var article: article
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(article.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(5)
            Text(article.title)
                .font(.system(.title, design: .rounded))
                .fontWeight(.black)
                .lineLimit(3)
                .padding(.bottom, 0)
            Text("By \(article.author)".uppercased())
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.bottom, 0)
            HStack(spacing: 3) {
                ForEach(1...(article.rating), id: \.self) { _ in
                    Image(systemName: "star.fill")
                        .font(.caption)
                        .foregroundColor(.yellow)
                }
            }
            Text(article.text)
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }
}
