//
//  SwiftUIListApp.swift
//  SwiftUIList
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

@main
struct SwiftUIListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
