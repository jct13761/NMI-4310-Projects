//
//  SwiftUIAnimationApp.swift
//  SwiftUIAnimation
//
//  Created by Jorrin Thacker on 3/14/21.
//

import SwiftUI

@main
struct SwiftUIAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
