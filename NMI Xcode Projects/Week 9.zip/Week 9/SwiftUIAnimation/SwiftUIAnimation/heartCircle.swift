//
//  heartCircle.swift
//  SwiftUIAnimation
//
//  Created by Jorrin Thacker on 3/14/21.
//

import SwiftUI

struct heartCircle: View {
    @State private var circleColorChanged = false
    @State private var heartColorChanged = false
    @State private var heartSizeChanged = false
    
    var body: some View {
        VStack {
            ZStack {
                Color.blue
                    .opacity(0.3)
                    .ignoresSafeArea()
                Circle()
                    .frame(width: 200, height: 200)
                    .foregroundColor(circleColorChanged ? Color(.systemGray5) : .red)
                Image(systemName: "heart.fill")
                    .foregroundColor(heartColorChanged ? .red : .white)
                    .font(.system(size: 100))
                    .scaleEffect(heartSizeChanged ? 1.0 : 0.5)
            }
            
            //        .animation(.default)
            //        .animation(.spring(response: 0.3, dampingFraction: 0.3, blendDuration: 0.3))
            
            
            // Implicit Animation
//            .onTapGesture {
//                withAnimation(.default) {
//                    self.circleColorChanged.toggle()
//                    self.heartColorChanged.toggle()
//                    self.heartSizeChanged.toggle()
//                }
//            }
            
            
            // Explicit Animation
            .onTapGesture {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.3, blendDuration: 0.3)
                ) {
                    self.heartSizeChanged.toggle()
                    self.heartColorChanged.toggle()
                }
                self.circleColorChanged.toggle()
            }
            
            
        }
    }
}

struct heartCircle_Previews: PreviewProvider {
    static var previews: some View {
        heartCircle()
    }
}
