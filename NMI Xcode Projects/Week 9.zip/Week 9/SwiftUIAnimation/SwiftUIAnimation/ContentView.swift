//
//  ContentView.swift
//  SwiftUIAnimation
//
//  Created by Jorrin Thacker on 3/14/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: heartCircle()){
                    Text("Heart Circle")
                }
                NavigationLink(destination: loading()){
                    Text("Loading Circle with Arc")
                }
                NavigationLink(destination: LoadingBar()){
                    Text("Loading Bar")
                }
                NavigationLink(destination: progressIndicator()){
                    Text("Progress Indicator")
                }
                NavigationLink(destination: delayedAnimation()){
                    Text("Delayed Animation")
                }
                NavigationLink(destination: rectToCir()){
                    Text("Rectangle To Circle")
                }
                NavigationLink(destination: simpleTransition()){
                    Text("Simple Transition")
                }
                NavigationLink(destination: combinedTrans()){
                    Text("Combined Transition")
                }
                NavigationLink(destination: asymTrans()){
                    Text("Asymetrical Transition")
                }
                Group {
                    NavigationLink(destination: FancyButton()){
                        Text("Fancy Button Asignment")
                    }
                    NavigationLink(destination: AnimatedViewTrans()){
                        Text("Animated View Transition Asignment")
                    }
                }
            }
            .buttonStyle(simpleStyle(color: .blue))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


struct simpleStyle: ButtonStyle {
    var color = Color.blue
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 300)
            .font(.title3)
            .foregroundColor(Color.black)
            .padding(8)
            .background(color)
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
