//
//  flagStorage.swift
//  FlagLists
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

struct flagStorage {
    var stateNames = ["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","NewHampshire","NewJersey","NewMexico","NewYork","NorthCarolina","NorthDakota","Ohio","Oklahoma","Oregon","Pennsylvania","RhodeIsland","SouthCarolina","SouthDakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","WestVirginia","Wisconsin","Wyoming"]


    var stateFlags =                 ["alabama","alaska","arizona","arkansas","california","colorado","connecticut","delaware","florida","georgia","hawaii","idaho","illinois","indiana","iowa","kansas","kentucky","louisiana","maine","maryland","mass","michigan","minnesota","mississippi","missouri","montana","nebraska","nevada","newhampshire","newjersey","newmexico","newyork","northcarolina","northdakota","ohio","oklahoma","oregon","pennsylvania","rhodeisland","southcarolina","southdakota","tennessee","texas","utah","vermont","virginia","washington","westvirginia","winconsin","wyoming"]


    var allstates = [states(name:"Alabama",image:"alabama"),
                     states(name:"Alaska",image:"alaska"),
                     states(name:"Arizona",image:"arizona"),
                     states(name:"Arkansas",image:"arkansas"),
                     states(name:"California",image:"california"),
                     states(name:"Colorado",image:"colorado"),
                     states(name:"Connecticut",image:"connecticut"),
                     states(name:"Delaware",image:"delaware"),
                     states(name:"Florida",image:"florida"),
                     states(name:"Georgia",image:"georgia"),
                     states(name:"Hawaii",image:"hawaii"),
                     states(name:"Idaho",image:"idaho"),
                     states(name:"Illinois",image:"illinois"),
                     states(name:"Indiana",image:"indiana"),
                     states(name:"Iowa",image:"iowa"),
                     states(name:"Kansas",image:"kansas"),
                     states(name:"Kentucky",image:"kentucky"),
                     states(name:"Louisiana",image:"louisiana"),
                     states(name:"Maine",image:"maine"),
                     states(name:"Maryland",image:"maryland"),
                     states(name:"Massachusetts",image:"mass"),
                     states(name:"Michigan",image:"michigan"),
                     states(name:"Minnesota",image:"minnesota"),
                     states(name:"Mississippi",image:"mississippi"),
                     states(name:"Missouri",image:"missouri"),
                     states(name:"Montana",image:"montana"),
                     states(name:"Nebraska",image:"nebraska"),
                     states(name:"Nevada",image:"nevada"),
                     states(name:"New Hampshire",image:"newhampshire"),
                     states(name:"New Jersey",image:"newjersey"),
                     states(name:"New Mexico",image:"newmexico"),
                     states(name:"New York",image:"newyork"),
                     states(name:"North Carolina",image:"northcarolina"),
                     states(name:"North Dakota",image:"northdakota"),
                     states(name:"Ohio",image:"ohio"),
                     states(name:"Oklahoma",image:"oklahoma"),
                     states(name:"Oregon",image:"oregon"),
                     states(name:"Pennsylvania",image:"pennsylvania"),
                     states(name:"Rhode Island",image:"rhodeisland"),
                     states(name:"South Carolina",image:"southcarolina"),
                     states(name:"South Dakota",image:"southdakota"),
                     states(name:"Tennessee",image:"tennessee"),
                     states(name:"Texas",image:"texas"),
                     states(name:"Utah",image:"utah"),
                     states(name:"Vermont",image:"vermont"),
                     states(name:"Virginia",image:"virginia"),
                     states(name:"Washington",image:"washington"),
                     states(name:"West Virginia",image:"westvirginia"),
                     states(name:"Wisconsin",image:"winconsin"),
                     states(name:"Wyoming",image:"wyoming")
       ]
}
