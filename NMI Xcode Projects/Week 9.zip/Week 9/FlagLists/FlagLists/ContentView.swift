//
//  ContentView.swift
//  SwiftUIAnimation
//
//  Created by Jorrin Thacker on 3/14/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: arrays()){
                    Text("Arrays")
                }
                NavigationLink(destination: collection()){
                    Text("Collection")
                }
                
            }
            .buttonStyle(simpleStyle(color: .blue))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


struct simpleStyle: ButtonStyle {
    var color : Color
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 300)
            .font(.title3)
            .foregroundColor(Color.black)
            .padding()
            .background(color)
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
