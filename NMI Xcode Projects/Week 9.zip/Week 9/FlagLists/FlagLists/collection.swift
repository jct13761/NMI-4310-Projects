//
//  collection.swift
//  FlagLists
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

struct collection: View {
    var body: some View {

        List(flagStorage().allstates.indices) { index in
            
            if (flagStorage().allstates[index].name == "Georgia") {
                BestState(sf: flagStorage().allstates[index])
            } else if (index % 2 == 0) {
                leftView(sf: flagStorage().allstates[index])
            } else {
                rightView(sf: flagStorage().allstates[index])
            }
        }

        
    }
}

struct collection_Previews: PreviewProvider {
    static var previews: some View {
        collection()
    }
}


struct states: Identifiable {
    var id = UUID()
    var name: String
    var image: String
}

struct leftView: View {
    var sf : states
    var body: some View {
        HStack {
            Image(sf.image)
                .resizable()
                .frame(width: 100, height: 100)
                .cornerRadius(5)
            Text(sf.name)
        }
    }
}

struct rightView: View {
    var sf : states
    var body: some View {
        HStack{
            Spacer()
            Text(sf.name)
            Image(sf.image)
                .resizable()
                .frame(width: 100, height: 100)
                .cornerRadius(5)
        }
    }
}

struct BestState: View {
    var sf : states
    var body: some View {
        ZStack {
            Image(sf.image)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 200)
                .cornerRadius(10)
                .overlay(
                    Rectangle()
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .opacity(0.2)
                )
            Text("🥳 " + sf.name + " 🥳")
                .font(.system(.title, design: .rounded))
                .fontWeight(.black)
                .foregroundColor(.white)
        }
    }
}
