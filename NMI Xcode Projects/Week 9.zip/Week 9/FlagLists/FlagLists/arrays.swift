//
//  arrays.swift
//  FlagLists
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

struct arrays: View {
    var body: some View {
        List(flagStorage().stateNames.indices, id: \.self) { index in
            if (index % 2 == 0) {
                HStack {
                    Image(flagStorage().stateFlags[index])
                        .resizable()
                        .frame(width: 100, height: 100)
                        .cornerRadius(5)
                    Text(flagStorage().stateNames[index])
                }
            } else {
                HStack{
                    Spacer()
                    Text(flagStorage().stateNames[index])
                    Image(flagStorage().stateFlags[index])
                        .resizable()
                        .frame(width: 100, height: 100)
                        .cornerRadius(5)
                }
            }
        }
    }
}

struct arrays_Previews: PreviewProvider {
    static var previews: some View {
        arrays()
    }
}
