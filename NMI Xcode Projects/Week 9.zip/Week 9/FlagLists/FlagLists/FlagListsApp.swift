//
//  FlagListsApp.swift
//  FlagLists
//
//  Created by Jorrin Thacker on 3/15/21.
//

import SwiftUI

@main
struct FlagListsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
