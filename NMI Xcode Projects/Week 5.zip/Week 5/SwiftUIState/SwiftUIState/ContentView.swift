//
//  ContentView.swift
//  SwiftUIState
//
//  Created by Jorrin Thacker on 2/12/21.
//

import SwiftUI

struct ContentView: View {
    
    //    @State private var isPlaying = false
    @State private var c1 = 0
    @State private var c2 = 0
    @State private var c3 = 0
    
    var body: some View {
        VStack {
            //            Button(action: {
            //                self.isPlaying.toggle()
            //            }) {
            //                Image(systemName: isPlaying ? "stop.circle.fill" : "play.circle.fill")
            //                    .font(.system(size: 150))
            //                    .foregroundColor(isPlaying ? .red : .green)
            //            }
            
            Text("\(c1 + c2 + c3)")
                .font(.system(size: 200, weight: .bold, design: .rounded))
            
            HStack {
                ButtonCounter(counter: $c1, color: .red)
                ButtonCounter(counter: $c2, color: .blue)
                ButtonCounter(counter: $c3, color: .green)
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ButtonCounter: View {
    
    @Binding var counter: Int
    var color: Color
    
    
    var body: some View {
        Button(action: {
            self.counter += 1
        }) {
            Circle()
                .frame(width: 100, height: 100)
                .foregroundColor(color)
                .overlay(
                    Text("\(counter)")
                        .font(.system(size: 50, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                )
        }
    }
}
