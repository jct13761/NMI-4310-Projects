//
//  path.swift
//  SwiftUIShapes
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct path: View {
    var body: some View {
        VStack {
            Path() { path in
                path.move(to: CGPoint(x: 20, y: 20))
                path.addLine(to: CGPoint(x: 300, y: 20))
                path.addLine(to: CGPoint(x: 300, y: 200))
                path.addLine(to: CGPoint(x: 20, y: 200))
            }
            .fill(Color.green)
            
            Path() { path in
                path.move(to: CGPoint(x: 20, y: 20))
                path.addLine(to: CGPoint(x: 300, y: 20))
                path.addLine(to: CGPoint(x: 300, y: 200))
                path.addLine(to: CGPoint(x: 20, y: 200))
                path.closeSubpath()
            }
            .stroke(Color.blue, lineWidth: 10)
            
        }
        
        
    }
}

struct path_Previews: PreviewProvider {
    static var previews: some View {
        path()
    }
}
