//
//  ContentView.swift
//  SwiftUIShapes
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: path()){
                    Text("path")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: curvedPath()){
                    Text("curvedPath")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: pieChart()){
                    Text("pieChart")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: shapeProtocol()){
                    Text("shapeProtocol")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: circleProgress()){
                    Text("circleProgress")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: donutChart()){
                    Text("donutChart")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



struct DawgStyle: ButtonStyle {
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 250)
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [Color.gray, Color.pink]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
        
    }
}
