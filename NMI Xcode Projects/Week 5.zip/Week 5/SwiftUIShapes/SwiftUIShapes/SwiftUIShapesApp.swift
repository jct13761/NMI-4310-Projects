//
//  SwiftUIShapesApp.swift
//  SwiftUIShapes
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

@main
struct SwiftUIShapesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
