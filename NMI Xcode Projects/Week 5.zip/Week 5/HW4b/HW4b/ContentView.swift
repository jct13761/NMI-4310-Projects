//
//  ContentView.swift
//  HW4b
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct ContentView: View {
    
    @State var isClicked = false
    @State var num = 0;
    
    var body: some View {
        VStack {
            Button(action: {
                self.isClicked.toggle()
                self.num += 2
            }) {
                Text("Click to change image!")
            }
            .buttonStyle(PrettyButton())
            
            Image(isClicked ? "dq1" : "dq2")
                .font(.system(size: 150))
                .padding()
                .frame(width: 300, height: 300)
            
            Text("\(self.num)")
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct PrettyButton: ButtonStyle {
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .font(.title)
            .frame(minWidth: 0, maxWidth: .infinity)
            .padding()
            .foregroundColor(.white)
            .background(LinearGradient(gradient: Gradient(colors: [Color("Purple"), Color("Green"), Color("Pink")]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(40)
            .padding(.horizontal, 15)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
        
    }
}
