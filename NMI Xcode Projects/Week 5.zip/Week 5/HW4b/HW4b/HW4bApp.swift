//
//  HW4bApp.swift
//  HW4b
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

@main
struct HW4bApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
