//
//  ContentView.swift
//  SliderChartHW
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct ContentView: View {
    
//    @State var celsius: Double = 0
    
    
    var body: some View {
        
        
        
        NavigationView {
            VStack {
                NavigationLink(destination: pieChart()){
                    Text("Pie Chart Slider")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: circle()){
                    Text("Circle Slider")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: Pie()){
                    Text("Pie Chart Offset")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
                NavigationLink(destination: MiracleMan()){
                    Text("Miracle Man")
                        .font(.largeTitle)
                        .foregroundColor(Color.black)
                }
                .buttonStyle(DawgStyle())
            }
        }
        

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct DawgStyle: ButtonStyle {
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 250)
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.pink]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
        
    }
}

