//
//  pieChart.swift
//  SliderChartHW
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct pieChart: View {
    @State var pieVal: Double = 90
    
    private var blueGradient = LinearGradient(gradient: Gradient(colors: [ Color.blue, Color.green ]), startPoint: .trailing, endPoint: .leading)
    
    var body: some View {
        VStack {
            //            Slider(value: $celsius, in: -100...100, step: 0.1)
            //            Text("\(celsius) Celsius is \(celsius * 9 / 5 + 32) Fahrenheit")
            
            Path { path in
                path.move(to: CGPoint(x: 200, y: 200))
                path.addArc(center: .init(x: 200, y: 200), radius: 100, startAngle: Angle(degrees: 0.0), endAngle: Angle(degrees: pieVal), clockwise: false)
            }
            .fill(blueGradient)
            .frame(width: 400, height: 400)
            
            Slider(value: $pieVal, in: 0...360, step: 1.0)
                .padding()
            Text("The current angle is \(Int(pieVal))")
                .font(.system(.title))
            
        }
    }
}

struct pieChart_Previews: PreviewProvider {
    static var previews: some View {
        pieChart()
    }
}
