//
//  SliderChartHWApp.swift
//  SliderChartHW
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

@main
struct SliderChartHWApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
