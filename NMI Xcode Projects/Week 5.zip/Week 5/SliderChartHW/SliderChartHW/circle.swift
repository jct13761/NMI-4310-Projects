//
//  circle.swift
//  SliderChartHW
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct circle: View {
    
    @State var cirVal: Double = 0.25
    
    private var purpleGradient = LinearGradient(gradient: Gradient(colors: [ Color(red: 207/255, green: 150/255, blue: 207/255), Color(red: 107/255, green: 116/255,blue: 179/255) ]), startPoint: .trailing, endPoint: .leading)
    
    var body: some View {
        VStack {
            
            
            Text("\(cirVal * 100)")
                .font(.system(.body, design: .rounded))
                .bold()
                .foregroundColor(Color(.systemGray))
                .padding()
            ZStack {
                Circle()
                    .stroke(Color(.systemGray6), lineWidth: 20)
                    .frame(width: 300, height: 300)
                Circle()
                    .trim(from: 0, to: CGFloat(cirVal))
                    .stroke(purpleGradient, lineWidth: 20)
                    .frame(width: 300, height: 300)
                    .overlay(
                        VStack {
                            Text("\(Int(cirVal * 100))%")
                                .font(.system(size: 80, weight: .bold, design: .rounded))
                                .foregroundColor(Color(.systemGray))
                            Text("Complete")
                                .font(.system(.body, design: .rounded))
                                .bold()
                                .foregroundColor(Color(.systemGray))
                        }
                    )
            }
            
            Slider(value: $cirVal, in: 0.0...1.0, step: 0.01)
                .padding()
        }
    }
}

struct circle_Previews: PreviewProvider {
    static var previews: some View {
        circle()
    }
}
