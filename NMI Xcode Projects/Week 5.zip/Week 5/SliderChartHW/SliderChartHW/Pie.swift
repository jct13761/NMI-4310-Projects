//
//  Pie.swift
//  SliderChartHW
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct Pie: View {
    var body: some View {
        ZStack {
            
            Path {
                path in
                path.move(to: CGPoint(x: 200, y: 200))
                path.addArc(center: .init(x: 200, y: 200), radius: 150, startAngle: Angle(degrees: 0.0), endAngle: Angle(degrees: 290), clockwise: true)
            }
            .fill(Color.yellow)
            
            Path {
                path in
                path.move(to: CGPoint(x: 200, y: 200))
                path.addArc(center: .init(x: 200, y: 200), radius: 150, startAngle: Angle(degrees: 290.0), endAngle: Angle(degrees: 260), clockwise: true)
            }
            .fill(Color.blue)
            Path {
                path in
                path.move(to: CGPoint(x: 200, y: 200))
                path.addArc(center: .init(x: 200, y: 200), radius: 150, startAngle: Angle(degrees: 260.0), endAngle: Angle(degrees: 160), clockwise: true)
            }
            .fill(Color.red)
            
            Path {
                path in
                path.move(to: CGPoint(x: 200, y: 200))
                path.addArc(center: .init(x: 200, y: 200), radius: 150, startAngle: Angle(degrees: 160.0), endAngle: Angle(degrees: 00), clockwise: true)
            }
            .fill(Color.green)
            .offset(x: 10, y: 20)
            .overlay(
                Text("Green People")
                    .font(.system(.title, design: .rounded))
                    .bold()
                    .foregroundColor(.white)
                    .offset(x: 65, y:-30)
            )
            
        }
        .padding(.trailing, 50)
    }
}

struct Pie_Previews: PreviewProvider {
    static var previews: some View {
        Pie()
    }
}
