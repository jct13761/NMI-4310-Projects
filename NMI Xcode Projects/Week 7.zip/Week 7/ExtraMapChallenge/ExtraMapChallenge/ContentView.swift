//
//  ContentView.swift
//  ExtraMapChallenge
//
//  Created by Jorrin Thacker on 3/1/21.
//



import SwiftUI
import MapKit

struct ContentView: View {
    @State private var coordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 40.7, longitude: -73.9), span: MKCoordinateSpan(latitudeDelta: 100.0, longitudeDelta: 100.0))
    
    //    init() {
    //        let map = MKMapView.appearance()
    //
    //        map.mapType = .hybrid /// Hybrid map type
    //
    //
    //        map.showsTraffic = false /// Traffic is not shown
    //        map.showsBuildings = true /// Buildings are shown
    //        map.showsScale = true /// The scale is shown
    //
    //        map.isRotateEnabled = true /// Rotating of the map is enabled
    //
    //        let annotation = MKPointAnnotation()
    //        annotation.title = "New York City"
    //        //            annotation.coordinate = coordinates
    //        map.addAnnotation(annotation) /// Adds a MKPointAnnotation at the location of NYC
    //
    //        map.pointOfInterestFilter = MKPointOfInterestFilter(including: [.airport]) /// Adds a POI filter that only displays airport locations
    //
    //    }
    
    @ViewBuilder var body: some View {
        Map(coordinateRegion: $coordinateRegion)
            .mapOptions()
        //            .mapStyle(MKMapType.hybrid)
    }
}

extension Map {
    func mapStyle(_ mapType: MKMapType, showScale: Bool = true, showTraffic: Bool = false) -> some View {
        //        let map = MKMapView.appearance()
        //        map.mapType = mapType
        //        map.showsScale = showScale
        //        map.showsTraffic = showTraffic
        let options = MKMapSnapshotter.Options()
        options.mapType = .hybrid
        options.showsBuildings = true
        return self
    }
    
    func mapOptions() -> some View {
        let options = MKMapSnapshotter.Options()
        options.mapType = .hybrid
        options.showsBuildings = true
        return self
    }
}

//private func makeSnapshotter(for country: Country, with size: CGSize)
//-> MKMapSnapshotter {
//    let options = MKMapSnapshotter.Options()
//    options.mapType = .hybrid
//    options.showsBuildings = true
//    // Force light mode snapshot
//    options.traitCollection = UITraitCollection(traitsFrom: [
//        options.traitCollection,
//        UITraitCollection(userInterfaceStyle: .light)
//    ])
//
//    return MKMapSnapshotter(options: options)
//}

//import SwiftUI
//import MapKit
//
//struct ContentView: View {
//    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
//
//    @State private var type: MKMapView
//
//
//    init() {
//        MKMapView.appearence().mapType = .sattelite
//
//    }
//
//    var body: some View {
////        MapViewUIKit(region: region, mapType: .satellite)
//        Map(coordinateRegion: $region)
//    }
//}
//
//
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


//struct MapViewUIKit: UIViewRepresentable {
//
//    let region: MKCoordinateRegion
//    let mapType : MKMapType
//
//    // 2.
//    func makeUIView(context: Context) -> MKMapView {
//        let mapView = MKMapView()
//        mapView.setRegion(region, animated: false)
//        mapView.mapType = mapType
//        return mapView
//    }
//
//    // 3.
//    func updateUIView(_ mapView: MKMapView, context: Context) {
//        mapView.mapType = mapType
//    }
//}
