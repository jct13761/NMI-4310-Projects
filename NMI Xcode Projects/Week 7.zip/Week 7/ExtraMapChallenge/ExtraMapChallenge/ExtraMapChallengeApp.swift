//
//  ExtraMapChallengeApp.swift
//  ExtraMapChallenge
//
//  Created by Jorrin Thacker on 3/1/21.
//

import SwiftUI

@main
struct ExtraMapChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
