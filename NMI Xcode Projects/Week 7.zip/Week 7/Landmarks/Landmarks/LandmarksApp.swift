//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Jorrin Thacker on 2/28/21.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
