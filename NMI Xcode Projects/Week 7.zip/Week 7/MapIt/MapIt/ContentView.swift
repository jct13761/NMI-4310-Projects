//
//  ContentView.swift
//  MapIt
//
//  Created by Jorrin Thacker on 2/28/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                Group { // Group 1
                    NavigationLink(destination: MapView(thelat: 33.89360820729234, thelong: -83.28959123911078, latDelta: 0.001, longDelta:  0.001, pickMap: 2)){
                        HStack {
                            Text("My House Standard")
                            Image(systemName: "house.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .green))
                    
                    NavigationLink(destination: MapView(thelat: 33.89360820729234, thelong: -83.28959123911078, latDelta: 0.001, longDelta:  0.001, pickMap: 1)){
                        HStack {
                            Text("My House Satalite ")
                            Image(systemName: "house.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .blue))

                    NavigationLink(destination: MapView(thelat: 33.89360820729234, thelong: -83.28959123911078, latDelta: 0.0001, longDelta:  0.0001, pickMap: 0)){
                        HStack {
                            Text("My House Satalite Flyover")
                            Image(systemName: "house.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .purple))
                } // Group
                
                Divider().padding(5)

                Group { // Group 2
                    NavigationLink(destination: MapView(thelat: 33.90096236739103, thelong: -83.38249192992119, latDelta: 0.003, longDelta:  0.003, pickMap: 2)){
                        HStack {
                            Text("Botanical Gardens Standard")
                            Image(systemName: "leaf.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .green))

                    
                    NavigationLink(destination: MapView(thelat: 33.90096236739103, thelong: -83.38249192992119, latDelta: 0.003, longDelta:  0.003, pickMap: 1)){
                        HStack {
                            Text("Botanical Gardens Satalite ")
                            Image(systemName: "leaf.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .blue))

                    NavigationLink(destination: MapView(thelat: 33.90096236739103, thelong: -83.38249192992119, latDelta: 0.0001, longDelta:  0.0001, pickMap: 0)){
                        HStack {
                            Text("Botanical Gardens Flyover")
                            Image(systemName: "leaf.fill")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .purple))
                } // Group
                
                Divider().padding(5)
                
                Group { // Group 3
                    NavigationLink(destination: MapView(thelat: 36.13315704148233, thelong: -112.09837743321818, latDelta: 0.15, longDelta:  0.15, pickMap: 2)){
                        HStack {
                            Text("Grand Canyon Standard")
                            Image(systemName: "wind")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .green))

                    NavigationLink(destination: MapView(thelat: 36.13315704148233, thelong: -112.09837743321818, latDelta: 0.15, longDelta:  0.15, pickMap: 1)){
                        HStack {
                            Text("Grand Canyon Satalite ")
                            Image(systemName: "wind")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .blue))

                    
                    NavigationLink(destination: MapView(thelat: 36.13315704148233, thelong: -112.09837743321818, latDelta: 0.15, longDelta:  0.15, pickMap: 0)){
                        HStack {
                            Text("Grand Canyon Flyover")
                            Image(systemName: "wind")
                        }
                    } // NavLink
                    .buttonStyle(mapStyle(color: .purple))

                    
                } // Group
                
            } // Vstack
            .padding(.vertical)
            
            
        } // NavView
    } // body
} // struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


struct mapStyle: ButtonStyle {
    var color = Color.blue
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(minWidth: 0, maxWidth: 300)
            .font(.title3)
            .foregroundColor(Color.black)
            .padding()
            .background(color)
            .cornerRadius(40)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}
