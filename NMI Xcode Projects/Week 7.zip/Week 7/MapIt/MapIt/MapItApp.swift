//
//  MapItApp.swift
//  MapIt
//
//  Created by Jorrin Thacker on 2/28/21.
//

import SwiftUI

@main
struct MapItApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
