//
//  krazyApp.swift
//  krazy
//
//  Created by Emuela on 11/13/20.
//

import SwiftUI

@main
struct krazyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
