//
//  ContentView.swift
//  krazy
//
//  Created by Emuela on 11/13/20.
//

import SwiftUI

struct ContentView: View {
    @State var name = ""
    @State var verb = ""
    @State var animal = ""
    @State var color = ""
    @State var size = ""
    @State var counter = 0
    var space = "_"
    var s = "s"
    var a = "a"
    @State private var verbcount = 0;
    @State private var colorCount = 0;
    var animals = ["dog","cat","hamster","turtle","horse","bear","jellyfish"]
    var verbs = ["like", "likes", "hate","hates","need","needs","want","wants"]
    var colors = ["red", "orange", "yellow", "green", "blue", "purple", "pink", "brown", "black", "gray"]
    var body: some View {
        VStack {
            Text("Enter your name, pick a verb and a pet. \nThen click the link to see your sentence")
                .font(.body)
                .multilineTextAlignment(.center)
            TextField("Enter your name", text: $name)
                .padding(.horizontal)
                .frame(width: 300)
            
            /////////
            
            VStack{
                
                Picker(selection: $verbcount, label: Text("why does this not work")) {
                    ForEach(0..<verbs.count) { //index in
                        Text(verbs[$0])
                    }}
                    .onReceive(
                        [self.verbcount].publisher.first()){
                        (value) in
                        verb = verbs[verbcount]
                    }
            }
            /////////
            
            HStack(){
                Stepper(onIncrement: {self.counter += 1
                    if self.counter == animals.count{
                        self.counter = 0
                    }
                    self.animal = self.animals[self.counter]
                },
                onDecrement: {
                    self.counter -= 1
                    if self.counter < 0{
                        self.counter = animals.count - 1
                    }
                    self.animal = self.animals[self.counter]
                }) {
                    Text("Select an animal: \(animals[counter])")
                }
            }
            .padding(.horizontal, 66)
            ////////////////
            
            TextField("Enter the a number from 0 to 50", text: $size)
                .padding()
                .frame(width: 300)
            
            VStack{
                
                Picker(selection: $colorCount, label: Text("why does this not work")) {
                    ForEach(0..<colors.count) { //index in
                        Text(colors[$0])
                    }}
                    .onReceive(
                        [self.colorCount].publisher.first()){
                        (value) in
                        color = colors[colorCount]
                    }
            }
                        
            if #available(iOS 14.0, *) {
                let message = name+space+verb+space+animal+s
                let urlString = "&one=%3Cp_style=%22color:"+color+";font-size:"+size+"px;%22%3E"+message+"_%3C/p%3E"
                
                Link(destination: URL(string: "https://emuel.mynmi.net/db2/telme.php?response="+urlString)!) {
                    Image(systemName: "link.circle.fill")
                        .font(.largeTitle)
                }
            } else {
                // Fallback on earlier versions
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


