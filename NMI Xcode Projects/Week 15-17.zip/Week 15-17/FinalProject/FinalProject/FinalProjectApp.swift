//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Jorrin Thacker on 5/5/21.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
