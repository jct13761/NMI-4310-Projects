//
//  circleProgress.swift
//  SwiftUIShapes
//
//  Created by Jorrin Thacker on 2/14/21.
//

import SwiftUI

struct circleProgress: View {
    @State var cirVal: Double
    
    var purpleGradient = LinearGradient(gradient: Gradient(colors: [ Color(hex: 0x000080), Color(hex: 0xff0066) ]), startPoint: .trailing, endPoint: .leading)
    
    var body: some View {
        VStack {
            Text("\(cirVal * 10)")
                .font(.system(.body, design: .rounded))
                .bold()
                .foregroundColor(Color(.systemGray))
                .padding()
            ZStack {
                Circle()
                    .stroke(Color(.systemGray6), lineWidth: 20)
                    .frame(width: 300, height: 300)
                Circle()
                    .trim(from: 0, to: CGFloat(cirVal * 0.1))
                    .stroke(purpleGradient, lineWidth: 20)
                    .frame(width: 300, height: 300)
                    .overlay(
                        VStack {
                            Text("\(Int(cirVal * 10))%")
                                .font(.system(size: 80, weight: .bold, design: .rounded))
                                .foregroundColor(Color(.systemGray))
                        }
                    )
            }
        }
    }
}

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }
}



struct circleProgress_Previews: PreviewProvider {
    static var previews: some View {
        circleProgress(cirVal: 9.3)
    }
}



