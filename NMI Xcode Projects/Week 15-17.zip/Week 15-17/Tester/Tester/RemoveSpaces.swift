//
//  RemoveSpaces.swift
//  Tester
//
//  Created by Jorrin Thacker on 5/8/21.
//

import SwiftUI
import Foundation
let string = "Hello World!"
let formattedString = string.replacingOccurrences(of: " ", with: "+") 


struct RemoveSpaces: View {
  
    var body: some View {
        Text("\(formattedString)")
    }
}

struct RemoveSpaces_Previews: PreviewProvider {
    static var previews: some View {
        RemoveSpaces()
    }
}
