////
////  TSwizzelUI.swift
////  Tester
////
////  Created by Jorrin Thacker on 5/5/21.
////
//
//import SwiftUI
//
//struct TSwizzelUI: View {
//    @State private var results = [Result]()
//    var body: some View {
//        List(results, id: \.overview) { item in
//            VStack(alignment: .leading) {
//                Text(item.original_language)
//                    .font(.headline)
//                Text(item.media_type)
//                if item.original_title != nil {
//                    Text(item.original_title!)
//                }
//                Text(item.overview)
//            }
//        }
//        .onAppear(perform: loadData)
//    }
//    func loadData() {
//        guard let url = URL(string: "https://api.themoviedb.org/3/search/multi?api_key=51bce37ace8570b6df21ef10a2c14269&language=en-US&query=Kong") else {
//            print("Invalid URL")
//            return
//        }
//        let request = URLRequest(url: url)
//        URLSession.shared.dataTask(with: request) { data, response, error in
//            if let data = data {
//                if let decodedResponse = try? JSONDecoder().decode(Response.self, from: data) {
//                    print("data!!")
//                    // we have good data – go back to the main thread
//                    DispatchQueue.main.async {
//                        // update our UI
//                        self.results = decodedResponse.results
//                        print(self.results)
//                    }
//                    // everything is good, so we can exit
//                    return
//                }
//            }
//            // if we’re still here it means there was a problem
//            print("Fetch failed: \(error?.localizedDescription ?? "Unknown error")")
//        }.resume()
//    }
//}
//struct Response: Codable {
//    var results: [Result]
//}
//struct Result: Codable {
//    var overview: String
//    var original_language: String
//    var media_type: String
//    var original_title: String?
//    // var id: Int
//    // var collectionName: String
//}
//
//
//struct TSwizzelUI_Previews: PreviewProvider {
//    static var previews: some View {
//        TSwizzelUI()
//    }
//}
//
//
