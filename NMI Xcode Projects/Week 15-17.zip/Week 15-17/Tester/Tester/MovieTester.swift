//
//  MovieTester.swift
//  Tester
//
//  Created by Jorrin Thacker on 5/7/21.
//

import SwiftUI

// MARK: - View
struct MovieTester: View {
    @State private var results = [Result]()
    var term : String
    
    
    var body: some View {
        List(results, id: \.overview) { item in
            ExtractedView(item: item)
        }
        .onAppear(perform: loadData)
    }
    
    
    // MARK: - loadData()

    func loadData() {
        let searchURL = "https://api.themoviedb.org/3/search/multi?api_key=51bce37ace8570b6df21ef10a2c14269&language=en-US&query=" + term
        guard let url = URL(string: searchURL) else {
            print("Invalid URL")
            return
        }
        let request = URLRequest(url: url)
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                if let decodedResponse = try? JSONDecoder().decode(Response.self, from: data) {
                    print("data!!")
                    // we have good data – go back to the main thread
                    DispatchQueue.main.async {
                        // update our UI
                        self.results = decodedResponse.results
                        print(self.results)
                    }
                    // everything is good, so we can exit
                    return
                }
            }
            // if we’re still here it means there was a problem
            print("Fetch failed: \(error?.localizedDescription ?? "Unknown error")")
        }.resume()
    }
}

// MARK: - Response Struct

struct Response: Codable {
    var results: [Result]
}

// MARK: - Results Struct

struct Result: Codable {
    var overview: String
    var original_language: String
    var media_type: String
    var original_title: String?
    var poster_path: String?
    var release_date: String?
    var backdropPath: String?
    var vote_average: Double?
}

// MARK: - MovieCardView

struct ExtractedView: View {
    var item: Result
    var posterURL = "https://image.tmdb.org/t/p/original//"
    
    var body: some View {
        HStack(alignment: .center) {
            
            if item.poster_path != nil {
                let urlString = posterURL + item.poster_path!
                RemoteImage(url: urlString)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 150)
            } else {
                Image(systemName: "photo")
                    .font(.system(size: 100))
                    .frame(width: 100, height: 150)
                    .padding(30)
            }
            
            VStack {
                HStack {
                    VStack {
                        
                        if item.original_title != nil {
                            Text(item.original_title!)
                                .font(.headline)
                                .fontWeight(.bold)
                        }
                        
//                        Text(item.release_date!)
                    }
                }
                .padding(.vertical)
                
                Text(item.overview)
                    .lineLimit(3)
            }
            .padding(5)
            .frame(maxWidth: .infinity)
            
            
        }
        .frame(width: .infinity)
        .cornerRadius(5)
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.black, lineWidth: 1)
                .shadow(radius: 20)
            
        )
    }
}

// MARK: - UI_Preview

struct MovieTester_Previews: PreviewProvider {
    static var previews: some View {
        MovieTester(term: "Jack+Reacher")
    }
}
