//
//  ContentView.swift
//  Tester
//
//  Created by Jorrin Thacker on 5/5/21.
//

import SwiftUI
import Foundation


struct ContentView: View {
    let urlString = "https://image.tmdb.org/t/p/original//ntRIoh8Qf1BI1AYGx0STfq0wUmb.jpg"
    
    
       var body: some View {
        
        VStack {
            Text("Hello")
            
            let urlString = "https://image.tmdb.org/t/p/original//ntRIoh8Qf1BI1AYGx0STfq0wUmb.jpg"
            RemoteImage(url: urlString)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200)
           
            AsyncImage(url: URL(string:  "https://image.tmdb.org/t/p/original//ntRIoh8Qf1BI1AYGx0STfq0wUmb.jpg")!, placeholder: { Text("Loading ...")
            },image: {
                Image(uiImage: $0).resizable()
            })
                .frame(idealHeight: UIScreen.main.bounds.width / 2 * 3) // 2:3 aspect ratio
        }
        
       }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
