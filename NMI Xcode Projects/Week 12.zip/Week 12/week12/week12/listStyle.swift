//
//  listStyle.swift
//  week12
//
//  Created by Jorrin Thacker on 4/5/21.
//

import SwiftUI

struct listStyle: View {
    
    
    
    init() {
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.largeTitleTextAttributes = [.underlineColor: UIColor.black,   .foregroundColor: UIColor.cyan, .font: UIFont(name: "ArialRoundedMTBold", size: 70)!]
        navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.gray, .font: UIFont(name: "ArialRoundedMTBold", size: 20)!]
        UINavigationBar.appearance().standardAppearance = navBarAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navBarAppearance
        UINavigationBar.appearance().compactAppearance = navBarAppearance
    }
    
    
    var body: some View {
        NavigationView {
            List(allstates) { index in
                NavigationLink(destination:
                                subView()
                ) {
                    
                    HStack {
                        Image(index.image)
                            .resizable()
                            .frame(width: 100, height: 100)
                            .cornerRadius(5)
                        Text(index.name)
                    }
                }
            }
            .navigationBarTitle("US States")
           
        }
    }
}

struct listStyle_Previews: PreviewProvider {
    static var previews: some View {
        listStyle()
    }
}

struct states: Identifiable {
    var id = UUID()
    var name: String
    var image: String
}


struct subView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            Text("Subview! Hit the custom back button")
                .font(.title)
                .padding()
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
                                Button(action: {
                                    self.presentationMode.wrappedValue.dismiss()
                                }, label: {
                                    HStack {
                                        Image(systemName: "backward.fill")
                                        Text("Go back")
                                    }
                                    .font(.title)
                                    .foregroundColor(Color(UIColor.magenta))
                                }))
    }
}


var allstates = [states(name:"Alabama",image:"alabama"),
                 states(name:"Alaska",image:"alaska"),
                 states(name:"Arizona",image:"arizona"),
                 states(name:"Arkansas",image:"arkansas"),
                 states(name:"California",image:"california"),
                 states(name:"Colorado",image:"colorado"),
                 states(name:"Connecticut",image:"connecticut"),
                 states(name:"Delaware",image:"delaware"),
                 states(name:"Florida",image:"florida"),
                 states(name:"Georgia",image:"georgia"),
                 states(name:"Hawaii",image:"hawaii"),
                 states(name:"Idaho",image:"idaho"),
                 states(name:"Illinois",image:"illinois"),
                 states(name:"Indiana",image:"indiana"),
                 states(name:"Iowa",image:"iowa"),
                 states(name:"Kansas",image:"kansas"),
                 states(name:"Kentucky",image:"kentucky"),
                 states(name:"Louisiana",image:"louisiana"),
                 states(name:"Maine",image:"maine"),
                 states(name:"Maryland",image:"maryland"),
                 states(name:"Massachusetts",image:"mass"),
                 states(name:"Michigan",image:"michigan"),
                 states(name:"Minnesota",image:"minnesota"),
                 states(name:"Mississippi",image:"mississippi"),
                 states(name:"Missouri",image:"missouri"),
                 states(name:"Montana",image:"montana"),
                 states(name:"Nebraska",image:"nebraska"),
                 states(name:"Nevada",image:"nevada"),
                 states(name:"New Hampshire",image:"newhampshire"),
                 states(name:"New Jersey",image:"newjersey"),
                 states(name:"New Mexico",image:"newmexico"),
                 states(name:"New York",image:"newyork"),
                 states(name:"North Carolina",image:"northcarolina"),
                 states(name:"North Dakota",image:"northdakota"),
                 states(name:"Ohio",image:"ohio"),
                 states(name:"Oklahoma",image:"oklahoma"),
                 states(name:"Oregon",image:"oregon"),
                 states(name:"Pennsylvania",image:"pennsylvania"),
                 states(name:"Rhode Island",image:"rhodeisland"),
                 states(name:"South Carolina",image:"southcarolina"),
                 states(name:"South Dakota",image:"southdakota"),
                 states(name:"Tennessee",image:"tennessee"),
                 states(name:"Texas",image:"texas"),
                 states(name:"Utah",image:"utah"),
                 states(name:"Vermont",image:"vermont"),
                 states(name:"Virginia",image:"virginia"),
                 states(name:"Washington",image:"washington"),
                 states(name:"West Virginia",image:"westvirginia"),
                 states(name:"Wisconsin",image:"winconsin"),
                 states(name:"Wyoming",image:"wyoming")
]
