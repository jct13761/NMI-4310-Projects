//
//  week12App.swift
//  week12
//
//  Created by Jorrin Thacker on 4/5/21.
//

import SwiftUI

@main
struct week12App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
