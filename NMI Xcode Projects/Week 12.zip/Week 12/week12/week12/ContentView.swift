//
//  ContentView.swift
//  week12
//
//  Created by Jorrin Thacker on 4/5/21.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
       
        
        NavigationView {
            VStack {
                NavigationLink(destination: week12.listStyle()){
                    Text("List Style")
                }
                NavigationLink(destination: week12.modalView()){
                    Text("Modal view")
                }
            }
            .font(.largeTitle)
            .foregroundColor(.red)
            .navigationBarTitle("Home", displayMode: .inline)
//            .navigationBarBackButtonHidden(true)


        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
