//
//  modalView.swift
//  week12
//
//  Created by Jorrin Thacker on 4/6/21.
//

import SwiftUI

struct modalView: View {
    
    @State var selectedArticle: states?
    
    
    var body: some View {
        NavigationView {
            List(allstates) { index in
                HStack {
                    Spacer()
                    
                    VStack {
                        Text(index.name)
                        Image(index.image)
                            .resizable()
                            .frame(width: 100, height: 100)
                            .cornerRadius(5)
                    }
                    Spacer()
                    
                }
                .onTapGesture {
                    self.selectedArticle = index
                }
                
            }
            .navigationBarTitle("US States")
            .sheet(item: self.$selectedArticle) { state in
                
                modalSubView(state: state)
                
            }
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
}

struct modalView_Previews: PreviewProvider {
    static var previews: some View {
        modalView()
    }
}


struct modalSubView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showAlert = false
    var state: states
    
    var body: some View {
        ZStack {
            Color.gray
                .ignoresSafeArea()
            VStack {
                Text(state.name)
                    .foregroundColor(.white)
                    .font(.title)
                Image(state.image)
                    .resizable()
                    .frame(width: 300, height: 300)
                    .cornerRadius(5)
            }
            .padding()
        }
        .ignoresSafeArea()
        .overlay(
            HStack {
                Spacer()
                VStack {
                    Button(action: {
                        self.showAlert = true
                    }, label: {
                        HStack {
                            Text("close")
                                .font(.title)
                            Image(systemName: "ladybug.fill")
                                .font(.largeTitle)

                        }
                        .foregroundColor(.white)
                    })
                    .padding(.trailing, 20)
                    .padding(.top, 40)
                    Spacer()
                }
            }
        )
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Reminder"), message: Text("Are you sure you are finished looking at this interesting flag?"), primaryButton: .default(Text("Yes"), action: { self.presentationMode.wrappedValue.dismiss() }), secondaryButton: .cancel(Text("No")))
        }
    }
}
