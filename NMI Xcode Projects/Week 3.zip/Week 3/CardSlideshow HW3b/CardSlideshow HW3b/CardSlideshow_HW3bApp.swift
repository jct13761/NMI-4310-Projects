//
//  CardSlideshow_HW3bApp.swift
//  CardSlideshow HW3b
//
//  Created by Jorrin Thacker on 2/1/21.
//

import SwiftUI

@main
struct CardSlideshow_HW3bApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
