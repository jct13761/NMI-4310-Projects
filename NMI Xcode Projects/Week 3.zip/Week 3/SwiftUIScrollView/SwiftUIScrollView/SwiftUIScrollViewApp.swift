//
//  SwiftUIScrollViewApp.swift
//  SwiftUIScrollView
//
//  Created by Jorrin Thacker on 1/29/21.
//

import SwiftUI

@main
struct SwiftUIScrollViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
