//
//  ContentView.swift
//  Homework 3
//
//  Created by Jorrin Thacker on 2/1/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            VStack {
                HStack {
                    Group {
                        Cards(image: "AC", heading: "Ace of Clubs")
                        Cards(image: "2C", heading: "Two of Clubs")
                        Cards(image: "3C", heading: "Three of Clubs")
                        Cards(image: "4C", heading: "Four of Clubs")
                        Cards(image: "5C", heading: "Five of Clubs")
                        Cards(image: "6C", heading: "Six of Clubs")
                        Cards(image: "7C", heading: "Seven of Clubs")
                        Cards(image: "8C", heading: "Eight of Clubs")
                        Cards(image: "9C", heading: "Nine of Clubs")
                        Cards(image: "10C", heading: "Ten of Clubs")
                    }
                    .frame(width: 350)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
