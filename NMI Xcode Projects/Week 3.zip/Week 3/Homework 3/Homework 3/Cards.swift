//  Cards.swift
//  Homework 3
//  Created by Jorrin Thacker on 2/1/21.

import SwiftUI

struct Cards: View {
    var image = "AC"
    var heading = "Ace of Clubs"
    
    var body: some View {
        ZStack {
            Color.red
                .opacity(0.5)
                .edgesIgnoringSafeArea(.all)
            VStack {
                Text(heading)
                    .font(.title)
                    .fontWeight(.black)
                    .foregroundColor(Color.red)
                Image(image)
                    .padding(53)
            }
            .padding(.bottom, 22)
            .padding()
            .background(Rectangle())
        }
        
    }
}

struct Cards_Previews: PreviewProvider {
    static var previews: some View {
        Cards()
    }
}
