//
//  Homework_3App.swift
//  Homework 3
//
//  Created by Jorrin Thacker on 2/1/21.
//

import SwiftUI

@main
struct Homework_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
